const cover = document.querySelector(".cover");
const pages = document.querySelectorAll(".page");
const slots = document.querySelectorAll(".slot");
const nextButton = document.getElementById("nextPage");
const prevButton = document.getElementById("prevPage");
const imageInput = document.getElementById("imageInput");
const pageNumber = document.getElementById("pageNumber");
const openSound = document.getElementById("openSound");

let currentSlot = null;
let currentPage = 0;

// Ajouter images
slots.forEach(slot => {
  slot.addEventListener("click", () => {
    currentSlot = slot;
    imageInput.click();
  });
});

imageInput.addEventListener("change", function() {
  const file = this.files[0];
  if (file && currentSlot) {
    const reader = new FileReader();
    reader.onload = function(e) {
      currentSlot.style.backgroundImage = `url(${e.target.result})`;
    };
    reader.readAsDataURL(file);
  }
});

// Mettre à jour numéro de page
function updatePageNumber() {
  if (cover.classList.contains("active")) {
    pageNumber.textContent = `Page 0 / ${pages.length}`;
  } else {
    pageNumber.textContent = `Page ${currentPage + 1} / ${pages.length}`;
  }
}

// Page suivante
nextButton.addEventListener("click", () => {
  if (cover.classList.contains("active")) {
    cover.classList.add("opened");
    cover.classList.remove("active");
    pages[0].classList.add("active");
    currentPage = 0;
    openSound.play(); // Son d’ouverture
    updatePageNumber();
    return;
  }

  pages[currentPage].classList.add("flipped");
  pages[currentPage].classList.remove("active");

  currentPage++;
  if (currentPage >= pages.length) currentPage = pages.length - 1;

  pages[currentPage].classList.add("active");
  updatePageNumber();
});

// Page précédente
prevButton.addEventListener("click", () => {
  if (currentPage === 0 && cover.classList.contains("opened")) {
    pages[0].classList.remove("active");
    cover.classList.add("active");
    cover.classList.remove("opened");
    updatePageNumber();
    return;
  }

  pages[currentPage].classList.remove("active");
  currentPage--;
  if (currentPage < 0) currentPage = 0;

  pages[currentPage].classList.remove("flipped");
  pages[currentPage].classList.add("active");
  updatePageNumber();
});

// Initial
updatePageNumber();
